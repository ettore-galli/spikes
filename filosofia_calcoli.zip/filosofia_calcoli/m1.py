from mutils import funzione

s = inputs["x"] + inputs["y"]
p = inputs["x"] * inputs["y"]


result = funzione(s, p)
