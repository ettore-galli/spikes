def funzione(a, b):
    return a**2 + b**2 + 1
